<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<div class="container mt-4">
  <div class="row">
    <div class="col">
      <h2>About Me.</h2>
      <p>Halo nama saya Mochamad Novaldy saya tinggal di cianjur, saya kuliah di Universitas Pasundan Bandung.</p>
    </div>
  </div>
</div>
<?= $this->endSection() ?>